  <footer class="footer text-center text-muted">
                <p style="color: red">Online Tiffin Service System.</p>
            </footer>